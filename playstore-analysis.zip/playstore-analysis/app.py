import streamlit as st
import pandas as pd
import plotly.express as px

# Set wide layout for dashboard
st.set_page_config(page_title="Google Play Store Analysis", layout="wide")

# Title
st.title(" Google Play Store Data Analysis")

# Load data
apps = pd.read_csv('data/cleaned_apps.csv')
reviews = pd.read_csv('data/cleaned_reviews.csv')
top_positive = pd.read_csv('data/top_positive_apps.csv')

# -------------------- Overview Section --------------------
st.subheader(" Dataset Overview")
col1, col2 = st.columns(2)
col1.metric("Total Apps", apps.shape[0])
col2.metric("Total Reviews", reviews.shape[0])

# -------------------- Apps per Category --------------------
st.subheader(" Number of Apps per Category")
category_counts = apps['Category'].value_counts().reset_index()
category_counts.columns = ['Category', 'Count']
fig1 = px.bar(
    category_counts,
    x='Category', y='Count',
    title="Apps per Category",
    labels={'Count': 'Number of Apps'},
)
st.plotly_chart(fig1, use_container_width=True)

# -------------------- Ratings Distribution --------------------
st.subheader(" Ratings Distribution")
fig2 = px.histogram(apps, x='Rating', nbins=30, title="Histogram of App Ratings")
st.plotly_chart(fig2, use_container_width=True)

# -------------------- Price vs Rating --------------------
st.subheader(" Price vs Rating")
free_paid_apps = apps[apps['Type'].isin(['Free', 'Paid'])]
fig3 = px.box(
    free_paid_apps,
    x='Type',
    y='Rating',
    color='Type',
    title="Rating Distribution: Free vs Paid Apps"
)
st.plotly_chart(fig3, use_container_width=True)

# -------------------- Install Trends --------------------
st.subheader("⬇ Install Trends")
apps['Installs'] = apps['Installs'].str.replace('+', '').str.replace(',', '').astype(int)
installs_group = apps.groupby('Category')['Installs'].sum().reset_index().sort_values(by='Installs', ascending=False).head(10)
fig4 = px.bar(
    installs_group,
    x='Category',
    y='Installs',
    title="Top 10 Categories by Total Installs"
)
st.plotly_chart(fig4, use_container_width=True)

# -------------------- Top Positive Apps Table --------------------
st.subheader(" Top Positive Reviewed Apps")
st.dataframe(top_positive)

# -------------------- Sentiment Distribution --------------------
st.subheader(" Sentiment Analysis of Reviews")
if 'Sentiment' in reviews.columns:
    sentiment_counts = reviews['Sentiment'].value_counts().reset_index()
    sentiment_counts.columns = ['Sentiment', 'Count']
    fig5 = px.pie(sentiment_counts, names='Sentiment', values='Count', title="Review Sentiment Distribution")
    st.plotly_chart(fig5, use_container_width=True)
else:
    st.warning(" Sentiment column not found in cleaned_reviews.csv.")

# -------------------- Average Rating per Category --------------------
st.subheader(" Average App Rating by Category")
avg_rating = apps.groupby('Category')['Rating'].mean().reset_index().sort_values(by='Rating', ascending=False).head(10)
fig6 = px.bar(
    avg_rating,
    x='Category',
    y='Rating',
    title="Top 10 Categories by Average Rating"
)
st.plotly_chart(fig6, use_container_width=True)


